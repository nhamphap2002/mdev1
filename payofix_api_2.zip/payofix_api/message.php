<html>
    <head>
        <title>Payofix</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="assets/js/bootstrap.js" type="text/javascript"></script>
<!--        <script src="assets/js/prototype.js" type="text/javascript"></script>
        <script src="assets/js/validation.js" type="text/javascript"></script>-->
    </head>
    <body>
        <div class="container">
            <div class="form-group clearfix">&nbsp;</div>
            <div class="form-group clearfix">&nbsp;</div>
            <div class="alert alert-success" role="alert">
                <?php
                echo $message;
                ?>
            </div>

        </div>
    </body>
</html>

