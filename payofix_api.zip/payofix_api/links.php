<?php
/*
 * Created on : Apr 3, 2019, 4:18:00 PM
 * Author: Tran Trong Thang
 * Email: trantrongthang1207@gmail.com
 * Skype: trantrongthang1207
 */
include_once 'config.php';
$table = TB_ORDERLINKS;
$mess = '';
if (!empty($_SESSION["login"])) {
    
} else {
    header('Location: login.php');
}
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
        <meta name="generator" content="Jekyll v3.8.5">
        <title>Create Link</title>
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="assets/js/bootstrap.js" type="text/javascript"></script>
        <style>
            .bd-placeholder-img {
                font-size: 1.125rem;
                text-anchor: middle;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
            }

            @media (min-width: 768px) {
                .bd-placeholder-img-lg {
                    font-size: 3.5rem;
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light bg-light rounded">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarsExample09">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="createlink.php">Createlink</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="links.php">Link</a>
                        </li>
                    </ul>
                    <form class="form-inline my-2 my-md-0">
                        <input class="form-control" type="text" placeholder="Search" aria-label="Search">
                    </form>
                </div>
            </nav>



            <main role="main">
                <div class="form-group"></div>
                <div>
                    <?php echo $mess; ?>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <?php
                        if (isset($_REQUEST["p"]))
                            $page = (int) $_REQUEST["p"];
                        else
                            $page = 1;
                        $setLimit = Limit;
                        $pageLimit = ($page * $setLimit) - $setLimit;

                        $fields = "*";
                        $sql = "SELECT " . $fields . " FROM " . $table . ' LIMIT ' . $pageLimit . " , " . $setLimit;
                        $db->query($sql);
                        $items = $db->loadObjectList();
                        ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">OrderId</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Website</th>
                                    <th scope="col">Created</th>
                                    <th scope="col">Link</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 1;
                                foreach ($items as $key => $value) {
                                    ?>
                                    <tr>
                                        <th scope="row">
                                            <?php
                                            echo $i;
                                            $i++;
                                            ?>
                                        </th>
                                        <td>
                                            <?php
                                            echo $value->orderid;
                                            ?>
                                        </td>
                                        <td>
                                            <?php
                                            echo $value->price;
                                            ?>
                                        </td>
                                        <td>
                                            <?php
                                            echo $value->website;
                                            ?>
                                        </td>
                                        <td>
                                            <?php
                                            echo $value->created;
                                            ?>
                                        </td>
                                        <td>
                                            <?php
                                            echo $value->link;
                                            ?>
                                        </td>
                                    </tr>
                                    <?php
                                }
                                ?>

                            </tbody>
                        </table>
                        <?php
                        $fields = "count(id) as count";
                        $sql = "SELECT " . $fields . " FROM " . $table;
                        $db->query($sql);
                        $total = $db->loadResult();
                        $setLastpage = ceil($total / $setLimit);
                        ?>
                        <nav aria-label="Page navigation example">
                            <ul class="pagination">
                                <?php if ($setLastpage > 1) { ?>
                                    <!--<li class="page-item"><a class="page-link" href="#">Previous</a></li>-->
                                    <?php
                                    for ($i = 1; $i < ($setLastpage + 1); $i++) {
                                        ?>
                                        <li class="page-item"><a class="page-link" href="?p=<?php echo $i ?>"><?php echo $i ?></a></li>    
                                            <?php
                                        }
                                        ?>
                                    <?php } ?>
                            </ul>
                        </nav>
                    </div>
                </div>
            </main>
        </div>

    </body>
</html>
