<?php

ini_set("display_errors", 1);
error_reporting(E_ALL);

require_once ( "../app/Mage.php" );
Mage::app();

if (isset($_GET['createtbl'])) {
    createTable();
    exit();
}

if (!empty($_GET['orderid'])) {
    $orderid = $_GET['orderid'];
    $order = Mage::getModel('sales/order')->load($_GET['orderid']);
    if ($order) {
//echo '<pre>';
//print_r($order->getData()); 
        $grand_total = $order['grand_total'];
        $IncrementId = $order['increment_id'];
        $customer_firstname = $order['customer_firstname'];
        $customer_lastname = $order['customer_lastname'];
        $customer_email = $order['customer_email'];
        $currency_code = $order['order_currency_code'];

        $order_Address = $order->getShippingAddress();
        if ($order_Address) {
//print_r(get_class_methods($order_Address)); 
            $custAddr = $order_Address->getStreetFull();
            $region = $order_Address->getRegion();
            $order_country_code = $order_Address->getCountry();
            $postcode = $order_Address->getPostcode();
            $telephone = $order_Address->getTelephone();
            $city = $order_Address->getCity();
        }

        include_once 'countries.php';

        include_once 'form.php';
    }
}

function createTable() {
    $resource = Mage::getSingleton('core/resource');
    $writeConnection = $resource->getConnection('core_write');
    $query = "CREATE TABLE `payofix_transactions` ( `id` INT NOT NULL AUTO_INCREMENT , `order_id` INT NOT NULL , `transaction_id` VARCHAR(100) NOT NULL , `created_date` DATETIME NOT NULL , PRIMARY KEY (`id`))";

    $writeConnection->query($query);
}

function saveTransactions($order_id, $transaction_id) {
    $resource = Mage::getSingleton('core/resource');
    $writeConnection = $resource->getConnection('core_write');
    $date_now = date("Y-m-d H:i:s");
    $query = "INSERT INTO `payofix_transactions` (`id`, `order_id`, `transaction_id`, `created_date`) VALUES (NULL, '$order_id', '$transaction_id', '$date_now');";

    $writeConnection->query($query);
}

?>