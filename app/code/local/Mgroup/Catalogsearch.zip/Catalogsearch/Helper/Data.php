<?php
/**
 * Created by PhpStorm.
 * User: tvl
 * Date: 01/06/2016
 * Time: 22:44
 */ 
class Mgroup_Catalogsearch_Helper_Data extends Mage_Core_Helper_Abstract {

}