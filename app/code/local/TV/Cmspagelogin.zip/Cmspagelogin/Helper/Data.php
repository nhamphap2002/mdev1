<?php
class TV_Cmspagelogin_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 