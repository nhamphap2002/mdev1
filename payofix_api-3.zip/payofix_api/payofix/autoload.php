<?php

class PayofixAutoloader {
    static public function load($className) {
    	$arr = explode("\\", $className);    	
    	if($arr[0] != "Payofix"){
    		return FALSE;
    	}

        $filename = __DIR__."/".str_replace('\\', '/', $className) . ".php";        
        if (file_exists($filename)) {        
            include($filename);
            if (class_exists($className)) {
                return TRUE;
            }
        }
        return FALSE;
    }
}

spl_autoload_register('PayofixAutoloader::load');